package com.kpmgml;

import java.io.Serializable;

public class AuthorVO implements Serializable {

	private static final long serialVersionUID = 1L;
	

	private String initials;
	private String lastName;
	
	private String keywords;
	
	private String articlePMId;
	private String articleDOI;

	

	

	public String getArticlePMId() {
		return articlePMId;
	}

	public void setArticlePMId(String articlePMId) {
		this.articlePMId = articlePMId;
	}

	public String getArticleDOI() {
		return articleDOI;
	}

	public void setArticleDOI(String articleDOI) {
		this.articleDOI = articleDOI;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getInitials() {
		return initials;
	}

	public void setInitials(String initials) {
		this.initials = initials;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	

}
