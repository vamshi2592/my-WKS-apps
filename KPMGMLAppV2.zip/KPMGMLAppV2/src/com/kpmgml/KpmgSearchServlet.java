package com.kpmgml;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalyzeOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.EntitiesOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.Features;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.KeywordsOptions;

public class KpmgSearchServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException,NoSuchElementException {
		
		 StringBuilder sb = new StringBuilder();
		 ArrayList<String> sentenceList = new ArrayList<String>();

		System.out.println("Inside Post..");
		
		String searchText = request.getParameter("searchText");
		
		/*Scanner fileScanner = null;
		try {
		    //fileScanner = new Scanner(new File(searchText+".txt")); -- change
			fileScanner = new Scanner(new File("D:/Workspace/KPMGMLAppV2/MyFile.txt"));
		} catch (FileNotFoundException e) {
		    e.printStackTrace();  
		}
		String eachSent="";
		while (fileScanner.hasNextLine()){		
		    
		    //System.out.println(fileScanner.nextLine());
		   try{
			   sentenceList.add(fileScanner.nextLine());
		   
		   		    
		    System.out.println("------------sb------" + sentenceList.size());
		    } catch (NoSuchElementException ex){
		    	
		    }
	   
		}
		
		fileScanner.close();
		
		 String[] sentenceArray = sentenceList.toArray(new String[sentenceList.size()]);

		 for (int r=0;r<sentenceArray.length;r++)
	       {
			 System.out.println("Sentence " + (r) + ": " + sentenceArray[r]);
			 sb.append(sentenceArray[r]);
	       
	       }
		*/
		
		//String srcWealth = request.getParameter("SrcWealth");
		
		String litigation = "";
				
		litigation = request.getParameter("Litigation");
		
		
		//System.out.println("------------SrcWealth------" + srcWealth);
		System.out.println("------------litigation------" + litigation);
		System.out.println("------------searchText------" + searchText);

		List list = new ArrayList<String>();
		List srcWealthList = new ArrayList();
		List litigationList = new ArrayList();

		String type = "";

		
		String text = searchText; //sb.toString();//
		
		System.out.println("------------text after SB------" +text);
		
		EntitiesOptions entitiesOptions = null;
		NaturalLanguageUnderstanding service = null;
		
		if(litigation.equalsIgnoreCase("Litigation")){
			
			System.out.println("------------Litigation Call------");
		
		 service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27,
				"14e908b8-531b-4f90-a906-710fc0474bac", "e1K2iUmXjpiJ");		

		 entitiesOptions = new EntitiesOptions.Builder()
				.emotion(true).sentiment(true).limit(2)
				.model("10:dffbb64a-c039-460b-b0e6-f64b6fa679cb").build();
				//.model("10:74369dd2-870a-4bb8-b997-1cda5a0e6517").build();
		} else {
			
			System.out.println("------------Source Wealth Call------");
			
			 service = new NaturalLanguageUnderstanding(
					NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27,
					"bf7a6b28-a7cb-4b07-9ca3-d0303f4ebc35", "CiHHmEuXCRh5");		

			 entitiesOptions = new EntitiesOptions.Builder()
					.emotion(true).sentiment(true).limit(2)
					.model("10:769fbf3e-0b42-4b6f-b06f-60233dc2f4de").build();
			
		}

		KeywordsOptions keywordsOptions = new KeywordsOptions.Builder()
				.emotion(true).sentiment(true).limit(2).build();

		Features features = new Features.Builder().entities(entitiesOptions)
				.keywords(keywordsOptions).build();

		AnalyzeOptions parameters = new AnalyzeOptions.Builder().text(text)
				.features(features).build();

		AnalysisResults response1 = service.analyze(parameters).execute();
		System.out.println(response1);

		// System.getProperties().put("proxySet", "true");
		// System.getProperties().put("proxyHost", "proxy.cognizant.com");
		// System.getProperties().put("proxyPort", "6050");

		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = new JSONObject();

		try {

			jsonObject = (JSONObject) jsonParser.parse(response1.toString());

			JSONArray jsonResponse = (JSONArray) jsonObject.get("entities");

			JSONObject results = new JSONObject();
			String entityText = "";
			
			

			for (int i = 0; i < jsonResponse.size(); i++) {
				results = (JSONObject) jsonResponse.get(i);
				entityText = (String) results.get("text");			
				
				
				//System.out.println("entityText::" + entityText);
               if(((String) results.get("type")).equalsIgnoreCase("litigation")){
				
				 type = (String) results.get("type");
				System.out.println("typei in litigation***::" + type);
				System.out.println("entityText***::" + entityText);
				litigationList.add(entityText);	
				request.setAttribute("litigationList", litigationList);
				
				request.setAttribute("MLoutput",type);
               } else if (entityText.equalsIgnoreCase("case")) {
					type = (String) results.get("type");
					System.out.println("case type***::" + type);
					request.setAttribute("entityText", "case");
					request.setAttribute("MLoutput", type);
				}else if(entityText.equalsIgnoreCase("charge")) {
					type = (String) results.get("type");
					System.out.println("Charge type***::" + type);
					request.setAttribute("entityText", "charge");
					request.setAttribute("MLoutput", type);

				}else if(((String)results.get("type")).equalsIgnoreCase("SOURCE_WEALTH")){
					
					type = (String) results.get("type");
					System.out.println("Charge type***::" + type);
					if(type.equalsIgnoreCase("SOURCE_WEALTH")){
						request.setAttribute("MLoutput", type);
						System.out.println("entityText***::" + entityText);
						srcWealthList.add(entityText);					
						
					}					
					
				} 

			}
			
			
			if(entityText==""){				

				System.out.println("Inside validate Enity text......");
				
				request.setAttribute("entityText", "");
				
			}
			
			if(type==""){				

				System.out.println("Inside validate ML text......");
				
				request.setAttribute("MLoutput", "");
				
			}
			

		} catch (ParseException e) {

			e.printStackTrace();
		}

		try {

			RequestDispatcher dispatcher = request
					.getRequestDispatcher("/outputPage.jsp");
			System.out.println("list : " + list.size());
			request.setAttribute("searchText", searchText);
			
			System.out.println("MLoutput***::" + type);
			System.out.println("srcWealthList length***::" + srcWealthList.size());
			request.setAttribute("srcWealthList", srcWealthList);

			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		
		
	}
	
	
	
	
	
	
}
