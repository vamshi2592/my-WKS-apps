package com.reviewclosure;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalyzeOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.EntitiesOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.Features;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.KeywordsOptions;

public class ReviewClosureSearchServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	@SuppressWarnings({ "unused" })
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, NoSuchElementException {

		StringBuilder sb = new StringBuilder();
		ArrayList<String> sentenceList = new ArrayList<String>();

		System.out.println("Inside Post..");

		String searchText = request.getParameter("searchTxt");
		System.out.println("------------searchText------" + searchText);
		
	    HashMap<Object,Object> missingElementsMap = new HashMap<Object, Object>();
		
		String text = searchText;
				//"Customer states that his sensor shows sensor ended. Performed visual inspection on returned sensor 0M0000WVCL0. No issues observed. Extracted data from returned Sensor using EVM and Sensor LabVIEW software. Sensor was in state 5 with event log 3 and 4 which is normal termination. Ref R was -5 which is inside the acceptable limits of -20 to 20. Observed sensor plug correctly seated in mount. All 3 contacts were installed properly. Crack found to be across the width of the sensor neck and through the carbon layer. Crack is consistent with an insertion error. Issue forward for review.";
				//"Performed visual inspection on returned sensor firm ware version 223. Visual inspection performed on sensor plug which was seated correctly. No cracks observed in sensor plug or on neck of sensor. Sensor Data extracted using EVM (s/n 064) and Sensor Labview software and patch found to be in sensor state 5. All three connectors installed properly.";//searchText; // sb.toString();//
                //Customer states try again in 10 minutes was shown at first then it switched to replace sensor. Performed visual inspection on returned sensor 0M0000UC9U8. No issues observed. Extracted data using EVM and LabVIEW software. Sensor was in state 5 with event log 3 and 4 which is normal termination. RefR was -6 which is inside the acceptable limits of -20 to 20. Observed sensor plug was properly seated in mount. Removed sensor plug and visually inspected. Observed all three contacts were installed properly. Performed visual inspection on sensor neck. Observed sensor neck was not cracked or damaged. Sensor was placed in simvivo fixture PRT26351-001 SV105 and reprogrammed using EVM and LabVIEW software with sensor load file 223. Performed simvivo test for 4 minutes. Sensor was read back using EVM and LabVIEW software. Sensor was in state 2 which is sensor detection state. Simvivo result was 2453 which is inside the acceptable limits of 947 to 3260 counts. RefR was -2. Issue forward for review.
		EntitiesOptions entitiesOptions = null;
		NaturalLanguageUnderstanding service = null;

		
		service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27,
				 "d8eece2a-5fee-4d5e-bdbd-b9594cc24b38", "33LkNIGS4lfA");
				//"bf7a6b28-a7cb-4b07-9ca3-d0303f4ebc35", "CiHHmEuXCRh5");

		entitiesOptions = new EntitiesOptions.Builder().emotion(true)
				.sentiment(true).limit(2)
				.model("10:539673d5-9d27-43de-8d4f-e3dcc924050c").build();
				//.model("10:4668a8ab-330f-4d32-9099-6b2369d5a4f1").build();

		KeywordsOptions keywordsOptions = new KeywordsOptions.Builder()
				.emotion(true).sentiment(true).limit(2).build();

		Features features = new Features.Builder().entities(entitiesOptions)
				.keywords(keywordsOptions).build();

		AnalyzeOptions parameters = new AnalyzeOptions.Builder().text(text)
				.features(features).build();

		AnalysisResults response1 = service.analyze(parameters).execute();
		System.out.println("JSON response is :"+response1);

		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = new JSONObject();

		try {
			 
			 String path = "C:/New folder/ReviewClosureApp/WebContent/rules/flowchartSteps.csv";
			 BufferedReader br = new BufferedReader(new FileReader(path));
			
			    String line =  null;
			    HashMap<Object,Object> mapProgramEntities = new HashMap<Object, Object>();
			    
			    Map<Object, Object> mapJsonEntities1 = new HashMap<Object, Object>();
		       
			    while((line=br.readLine())!=null){
			        String str[] = line.split(",");
			        for(int i=0;i<str.length;i++){
			            String arr[] = str[i].split(":");
			            mapProgramEntities.put(arr[0], arr[1]);
			        }
			       
			    }
			    
			    System.out.println("Map details:"+mapProgramEntities);

			    br.close();

			jsonObject = (JSONObject) jsonParser.parse(response1.toString());

			JSONArray jsonResponse = (JSONArray) jsonObject.get("entities");

			JSONObject results = new JSONObject();
			String entityType = "";
			String entityText = "";

			for (int i = 0; i < jsonResponse.size(); i++) {
				results = (JSONObject) jsonResponse.get(i);
				entityType = (String) results.get("type");
				entityText = (String) results.get("text");
				mapJsonEntities1.put(entityType,entityText);
				
			}

			
			 for(Map.Entry<Object, Object> entryMapA:mapProgramEntities.entrySet())
		        {
		            if(!mapJsonEntities1.containsKey(entryMapA.getKey()))
		                {
		                    System.out.println(entryMapA.getKey() +":"+entryMapA.getValue()+ " is not present in JSON");
		                    missingElementsMap.put(entryMapA.getKey(), entryMapA.getValue());
		                } 
		        }
			

		} catch (Exception e) {

			e.printStackTrace();
		}

		try {

			RequestDispatcher dispatcher = request
					.getRequestDispatcher("/outputPage.jsp");
			
			//request.setAttribute("searchText", searchText);
			request.setAttribute("missingElementsMap", missingElementsMap);
			System.out.println("missingElementsMap size : " + missingElementsMap.size());

			dispatcher.forward(request, response);
		} catch (ServletException e) {
			
			e.printStackTrace();
		}
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException {

	}

}
