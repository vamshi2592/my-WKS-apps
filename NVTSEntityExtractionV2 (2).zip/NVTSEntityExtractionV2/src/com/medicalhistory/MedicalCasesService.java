package com.medicalhistory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class MedicalCasesService {
	
	 public static ArrayList<MedicalCases> getListOfCases() throws IOException {

	        ArrayList<MedicalCases> cases = new ArrayList<MedicalCases>();
	        HashMap<String,String> narrativeHM = new HashMap<>();	        

			//String csvFile = "C:/Users/282773/workspace/NVSMedicalHistoryApp/WebContent/files/NarrationDump.csv";
	        String csvFile = "C:/New folder/NarrationCSVDump.csv";//"C:/Users/282773/workspace/NVSMedicalHistoryApp/WebContent/files/NarrationDump.csv";
	        BufferedReader br = null;
	        String line = "";
	        String cvsSplitBy = "##";
	        
          br = new BufferedReader(new FileReader(csvFile));
            
            
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] output = line.split(cvsSplitBy);
               
                  	MedicalCases newCase = new MedicalCases(Integer.valueOf(output[0]), output[1], output[2], output[3], output[4]);
                	cases.add(newCase);                     
                	narrativeHM.put(output[2], output[4]);
                    //System.out.println("Output is [country= " + output[1] + " , caseId=" + output[2] + " , CreatedDt=" + output[3] + "]");
                  
                  
	        }
            br.close();
	        return cases;
	    }
	 
	 public static HashMap<String,String> getNarrativeOfCases() throws IOException {

	        
	        HashMap<String,String> narrativeHM = new HashMap<>();
	        

			String csvFile = "C:/New folder/NarrationCSVDump.csv";//"C:/Users/282773/workspace/NVSMedicalHistoryApp/WebContent/files/NarrationDump.csv";
	        BufferedReader br = null;
	        String line = "";
	        String cvsSplitBy = "##";
	        
       br = new BufferedReader(new FileReader(csvFile));
         
         
         while ((line = br.readLine()) != null) {

             // use comma as separator
             String[] output = line.split(cvsSplitBy);       
              	       
             narrativeHM.put(output[2], output[4]);
             //System.out.println("narrativeHM Size ::" + narrativeHM.size());
               
	        }
         br.close();
	        return narrativeHM;
	    }

}
