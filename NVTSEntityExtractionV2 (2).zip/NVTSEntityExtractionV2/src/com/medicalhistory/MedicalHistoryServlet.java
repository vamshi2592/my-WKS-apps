package com.medicalhistory;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalyzeOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.EntitiesOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.Features;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.KeywordsOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationsOptions;


public class MedicalHistoryServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, NoSuchElementException, ServletException {
    HttpSession session = request.getSession(true);
		
		String narrationStr="";
		
		String selectedValHidden = request.getParameter("selected_val__hidden");
		
		//System.out.println("Inside Post..."+selectedValHidden);
		
		 HashMap<String,String>  narration =  MedicalCasesService.getNarrativeOfCases();
		 for(Map.Entry<String, String> entryMapA:narration.entrySet())
	      {
			 //System.out.println(entryMapA.getKey() +":"+entryMapA.getValue());	
	      
             if(entryMapA.getKey().equalsIgnoreCase(selectedValHidden)){
            	  narrationStr = entryMapA.getValue();
             }
             request.setAttribute("narration", narrationStr);         
	              
	      }
		 
		 String searchText = request.getParameter("searchTxt");
         
         
      HashMap<Object,Object> missingElementsMap = new HashMap<Object, Object>();
      HashMap<String,String> eventMap = new HashMap<String, String>();
         
         String text = narrationStr;//"This non-interventional clinical trial report was received from the study site on 13SEP2016, 14SEP2016, and 20SEP2016. The subject (ID: 12345) was enrolled in protocol XZT. A 33-year-old Caucasian female subject received the first dose of oral DRUG A 10 mg BID on 31AUG2015 for polycythemia vera. The last dose of DRUG A, prior to the serious adverse event (SAE), was not provided. Relevant medical history included: chronic tobacco abuse, urinary tract infection, blurred vision, bone pain, dizziness, headache, migraines, tiredness, vision problems, and G1P1T1 (gravida one, para one, term one)(in 2004). Relevant concomitant medications included: XXX, XXX, XXX, XXX, XXX and XXX. Baseline laboratory values, relevant to the SAE, were not provided. On 01SEP2015, DRUG A dose was changed due to lack of efficacy. On 18SEP2015, the subject started taking DRUG A 20 mg BID. The subject called the clinic informing that her menstrual cycle was on 31OCT2015, and two weeks late. She was sexually active utilizing the rhythm method, as well as, was using protection. On the same date, she was referred to high risk obstetrics (OB). On 03DEC2015, the subject took a urine pregnancy test which was positive and experienced a urinary tract infection (UTI). On 04DEC2015, the subject started taking DRUG A 10 mg BID. On 06DEC2015, the subject had excessive uterine bleeding and cramping. On 07DEC2015, the subject presented for medical care and was found to have had a miscarriage. A trans-vaginal ultrasound (US) revealed a failed pregnancy with an incomplete abortion/ abortion in progress. On the same date, the event of miscarriage was considered recovered and the event of pregnancy was considered recovered with sequelae. On 11DEC2015, the event of urinary tract infection was considered recovered. The physician had a detailed discussion with the subject regarding appropriate contraception. The subject also had a gynecology appointment to ensure no retained fetal material and that her blood human chorionic gonadotropin (bHCG) was falling appropriately. The subject was stable but sad about the miscarriage. The subject was also advised that if she was planning to conceive, that DRUG A therapy had to be tapered and that she had to be off DRUG A for more than three months. On 18MAY2016, concomitant medication omeprazole was stopped due to lack of efficacy. DRUG A therapy was ongoing. The subject�s due date was initially calculated as 06AUG2016. The investigator considered the event of urinary tract infection to be non-serious and assessed that there is not a reasonable possibility that DRUG A caused the reported event of urinary tract infection. The investigator considered the events of miscarriage and pregnancy to be serious (important medical event) and assessed that there is a reasonable possibility that DRUG A caused the reported event of miscarriage. The investigator assessed that there is not a reasonable possibility that DRUG A caused the reported event of pregnancy. The investigator further reported that he felt the event of miscarriage was likely due to disease but could possibly be related to DRUG A. No alternate causality was reported. Comment (21SEP2016): Currently, there is insufficient medical evidence to suggest a causal association between this subject's spontaneous abortion and exposure to DRUG A. Upon follow-up, subject had a previous term pregnancy, however additional confounding factors include chronic history of smoking, recent UTI and possible fetal exposure to aspirin, hydroxyurea, and Zoloft. Additionally, the role of Polycythemia Vera cannot be ruled out. Serious event of miscarriage was assessed as unlisted per the USPI DRUG A. Follow-up was received on 30NOV2016 from the investigator site. Updated DRUG A dosing details (reason dose was modified, dosing regimen starting on 03DEC2015 was deleted and new regimen starting 04DEC2015 was added) and updated concomitant medication details were provided (reason dose was modified, updated dosing regimens and deleted regimens). The narrative was updated accordingly. We forward this information to you in compliance with the guidelines of Good Clinical Practice and adverse event regulations applicable to clinical trial safety data and to increase investigators diligence in surveying for similar events.";
        
         EntitiesOptions entitiesOptions = null;
         NaturalLanguageUnderstanding service = null;
         RelationsOptions relations = null;
         
         service = new NaturalLanguageUnderstanding(
                      NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27,
                      "d8eece2a-5fee-4d5e-bdbd-b9594cc24b38", "33LkNIGS4lfA");
                      //"bf7a6b28-a7cb-4b07-9ca3-d0303f4ebc35", "CiHHmEuXCRh5");

         //relations = new RelationsOptions.Builder().model("10:81b4dba0-f0f5-462f-af26-12e2ab7e2577").build();
         relations = new RelationsOptions.Builder().model("10:88dffc9c-cf2d-4706-9068-a60d9aa10f7c").build();
        // relations = new RelationsOptions.Builder().model("10:539673d5-9d27-43de-8d4f-e3dcc924050c").build(); 
         
         entitiesOptions = new EntitiesOptions.Builder().emotion(true)
                      .sentiment(true).limit(2)
                      //.model("10:539673d5-9d27-43de-8d4f-e3dcc924050c").build();
                      .model("10:88dffc9c-cf2d-4706-9068-a60d9aa10f7c").build();
                      //.model("10:81b4dba0-f0f5-462f-af26-12e2ab7e2577").build();

         KeywordsOptions keywordsOptions = new KeywordsOptions.Builder()
                      .emotion(true).sentiment(true).limit(2).build();

         Features features = new Features.Builder().relations(relations).entities(entitiesOptions)
                      .keywords(keywordsOptions).build();

         AnalyzeOptions parameters = new AnalyzeOptions.Builder().text(text)
                      .features(features).build();

         AnalysisResults response1 = service.analyze(parameters).execute();
         System.out.println("JSON response is :"+response1);

         JSONParser jsonParser = new JSONParser();
 		JSONObject jsonObject = new JSONObject();

 		try {
 			
 			jsonObject = (JSONObject) jsonParser.parse(response1.toString());
 			//jsonObject  = (JSONObject) jsonParser.parse(new FileReader("d:\\nvtjson1.json"));
 			
 			JSONArray mainEntityArr = (JSONArray) jsonObject.get("entities");
 			JSONObject mainEntityObj = new JSONObject();
 			String mainEntity_Type = "";
			String suspect_medication_Text= "";
 			for (int l = 0; l < mainEntityArr.size(); l++) {
 				
 				mainEntityObj = (JSONObject) mainEntityArr.get(l);
 				
 				mainEntity_Type = (String) mainEntityObj.get("type");
				//System.out.println("mainEntity_Type::"+mainEntity_Type);
				if(mainEntity_Type.equalsIgnoreCase("suspect_medication")){
				suspect_medication_Text = (String) mainEntityObj.get("text");
				//System.out.println("suspect_medication_Text::"+suspect_medication_Text);
				}
				// Event Outcome code
				if (mainEntity_Type.equalsIgnoreCase("outcome_recover")) {
					request.setAttribute("eventOutcome", "RECOVERED");
				} else if (mainEntity_Type.equalsIgnoreCase("outcome_fatal_death")) {
					request.setAttribute("eventOutcome", "FATAL DEATH");
				} else if (mainEntity_Type.equalsIgnoreCase("outcome_worse")) {
					request.setAttribute("eventOutcome", "WORSEN");
				} else if (mainEntity_Type.equalsIgnoreCase("outcome_improve")) {
					request.setAttribute("eventOutcome", "IMPROVING");
				} else if (mainEntity_Type.equalsIgnoreCase("outcome_nochange")) {
					request.setAttribute("eventOutcome", "NO CHANGE");
				}
			}

			JSONArray relationArr = (JSONArray) jsonObject.get("relations");
			//System.out.println("relationArr::"+relationArr);
			JSONObject arguments = new JSONObject();
			String relType = "";
			
			JSONObject entities = new JSONObject();
			
			
			ArrayList<MedicalCases> eventBeginRecords = new ArrayList<MedicalCases>();
			ArrayList<MedicalCases> concomitantDrugRecords = new ArrayList<MedicalCases>();
			ArrayList<MedicalCases> suspectDrugRecords = new ArrayList<MedicalCases>();
			ArrayList<MedicalCases> suspectDrugDosageRecords = new ArrayList<MedicalCases>();
			ArrayList<MedicalCases> medicalHistoryRecords = new ArrayList<MedicalCases>();
			
			for (int i = 0; i < relationArr.size(); i++) {
				
				arguments = (JSONObject) relationArr.get(i);
				relType = (String) arguments.get("type");
				//System.out.println("relType::"+relType);
				////if relation is event begin
				if(relType.equalsIgnoreCase("event_begin")|| relType.equalsIgnoreCase("event_since") || relType.equalsIgnoreCase("event_end") ){
					
					String entityText_Event;
					String entityType_Event= "";
					String eventStartDate="";
					String eventDuration="";
					String eventEndDate="";
					
					MedicalCases mc = new MedicalCases();			
					
					JSONArray argumentsArr = (JSONArray) arguments.get("arguments");
					for (int j = 0; j < argumentsArr.size(); j++) {
						JSONObject argumentObj = (JSONObject) argumentsArr.get(j);
					JSONArray entitiesArr = (JSONArray) argumentObj.get("entities");
					for (int k = 0; k < entitiesArr.size(); k++) {
						
						entities = (JSONObject) entitiesArr.get(k);
						entityType_Event = (String) entities.get("type");
						if(entityType_Event.equalsIgnoreCase("event")){
							 entityText_Event = (String) entities.get("text");
							  mc.setEntityType_EventBegin(entityText_Event);
							
						} 
						if(entityType_Event.equalsIgnoreCase("duration")) {
							
							eventDuration = (String) entities.get("text");
							 mc.setEventDuration(eventDuration);
						} 
						
						if(relType.equalsIgnoreCase("event_begin")){
							if(entityType_Event.equalsIgnoreCase("date")){
								
								eventStartDate = (String) entities.get("text");
								 mc.setEntityText_EventBegin(eventStartDate);
							}
						}
						
						if(relType.equalsIgnoreCase("event_end")){
							if(entityType_Event.equalsIgnoreCase("date")){
								
								eventEndDate = (String) entities.get("text");
								 mc.setEventEndDate(eventEndDate);
							}
						}
				
					    //eventMap.put(mc.setEntityType_EventBegin(entityText_Event), mc.setEntityText_EventBegin(entityText_StDate));
					}
				}
					eventBeginRecords.add(mc);
					request.setAttribute("eventMap", eventBeginRecords);
				} else if (relType.equalsIgnoreCase("reportedOn")) {

					String entityType_rpt = "";
					String entityText_rpt = "";

					JSONArray argumentsArr1 = (JSONArray) arguments.get("arguments");
					for (int j = 0; j < argumentsArr1.size(); j++) {
						JSONObject argumentObj = (JSONObject) argumentsArr1.get(j);
						JSONArray entitiesArr = (JSONArray) argumentObj.get("entities");
						
						for (int k = 0; k < entitiesArr.size(); k++) {
							
							entities = (JSONObject) entitiesArr.get(k);
							entityType_rpt = (String) entities.get("type");
							if(entityType_rpt.equalsIgnoreCase("date")){
								entityText_rpt = (String) entities.get("text");
								// mc1.setEntityType_rptOn(entityText_rpt);
								// System.out.println("entityText_rpt##########::"+entityText_rpt);
								request.setAttribute("infoRecvDt", entityText_rpt);

							}
						}
					}
					
				} else if (relType.equalsIgnoreCase("concomitantDrug")){			
					
					MedicalCases mc2 = new MedicalCases();	
                    	
                    String entityType_con= "";
                    String entityText_con ="";  
                    String startDateConcomitant="";//Need to do
                    String endDateConcomitant="";//Need to do
                    String dosageConcomitant="";
					
					JSONArray argumentsArr2 = (JSONArray) arguments.get("arguments");
					for (int j = 0; j < argumentsArr2.size(); j++) {
						JSONObject argumentObj = (JSONObject) argumentsArr2.get(j);
						JSONArray entitiesArr2 = (JSONArray) argumentObj.get("entities");
						
						for (int k = 0; k < entitiesArr2.size(); k++) {
							
							entities = (JSONObject) entitiesArr2.get(k);
							entityType_con = (String) entities.get("type");
							if(entityType_con.equalsIgnoreCase("drugs") || entityType_con.equalsIgnoreCase("suspect_medication")){
								entityText_con = (String) entities.get("text");							
								//System.out.println("entityText_con##########::"+entityText_con);
								mc2.setDrugName_con(entityText_con);							
							}
							if(entityType_con.equalsIgnoreCase("dose")){
								dosageConcomitant = (String) entities.get("text");							
								//System.out.println("dosageConcomitant##########::"+dosageConcomitant);
								mc2.setDosage_con(dosageConcomitant);						
							}
							mc2.setStartDate_con(startDateConcomitant);//Need to do
							mc2.setEndDate_con(endDateConcomitant);//Need to do
						}
					}

					concomitantDrugRecords.add(mc2);
					request.setAttribute("concomitantDrug", concomitantDrugRecords);

				} else if (relType.equalsIgnoreCase("suspect_drug_begin")
						|| relType.equalsIgnoreCase("suspect_drug_since")
						|| relType.equalsIgnoreCase("suspect_drug_end")) {

					MedicalCases mc3 = new MedicalCases();

					String entityType_susp = "";
					String entityText_susp = "";
					String suspectStartDate = "";
					String suspectEndDate = "";
					String suspectDuration = "";

					JSONArray argumentsArr3 = (JSONArray) arguments.get("arguments");
					for (int j = 0; j < argumentsArr3.size(); j++) {
						JSONObject argumentObj = (JSONObject) argumentsArr3.get(j);
						JSONArray entitiesArr3 = (JSONArray) argumentObj.get("entities");
						
						for (int k = 0; k < entitiesArr3.size(); k++) {
							
							entities = (JSONObject) entitiesArr3.get(k);
							entityType_susp = (String) entities.get("type");
							if(entityType_susp.equalsIgnoreCase("suspect_medication") || entityType_susp.equalsIgnoreCase("suspect_medication")){
								entityText_susp = (String) entities.get("text");							
								//System.out.println("Suspect Name ######::"+entityText_susp);
								mc3.setSuspectName(entityText_susp);
							}
								
							if (relType.equalsIgnoreCase("suspect_drug_begin")){
								if(entityType_susp.equalsIgnoreCase("date")){
									suspectStartDate = (String) entities.get("text");							
									//System.out.println("suspectStartDate #######::"+suspectStartDate);
									mc3.setSuspectStartDt(suspectStartDate);
								}
							}
							
							if(entityType_susp.equalsIgnoreCase("duration")){
								suspectDuration = (String) entities.get("text");							
								//System.out.println("suspectDuration #######::"+suspectDuration);
								mc3.setSuspectDuration(suspectDuration);
							}
							
							
							if (relType.equalsIgnoreCase("suspect_drug_end")){
								if(entityType_susp.equalsIgnoreCase("date")){
									suspectEndDate = (String) entities.get("text");							
									//System.out.println("suspectEndDate #######::"+suspectEndDate);
									mc3.setSuspectEndDt(suspectEndDate);
								}
							}
									
							
						}
					}

					suspectDrugRecords.add(mc3);
					request.setAttribute("suspectDrug", suspectDrugRecords);

				} else if (relType.equalsIgnoreCase("suspect_drug_dosage")) {

					MedicalCases mc4 = new MedicalCases();

					String entityType_susp = "";
					String entityText_susp = "";
					String suspectStartDate = "";// Need to do
					String suspectEndDate = "";// Need to do
					String SuspectDosage = "";// Need to do

					JSONArray argumentsArr4 = (JSONArray) arguments.get("arguments");
					for (int j = 0; j < argumentsArr4.size(); j++) {
						JSONObject argumentObj = (JSONObject) argumentsArr4.get(j);
						JSONArray entitiesArr4 = (JSONArray) argumentObj.get("entities");
						
						for (int k = 0; k < entitiesArr4.size(); k++) {
							
							entities = (JSONObject) entitiesArr4.get(k);
							entityType_susp = (String) entities.get("type");
							if(entityType_susp.equalsIgnoreCase("suspect_medication") || entityType_susp.equalsIgnoreCase("suspect_medication")){
								entityText_susp = (String) entities.get("text");							
								//System.out.println("Suspect Name in Dosage ######::"+entityText_susp);
								mc4.setSuspectName(entityText_susp);
							}
								
							if(entityType_susp.equalsIgnoreCase("date")){
								suspectStartDate = (String) entities.get("text");							
								//System.out.println("suspectStartDate in Dosage #######::"+suspectStartDate);
								mc4.setSuspectStartDt(suspectStartDate);
							}							
							if(entityType_susp.equalsIgnoreCase("dose")){
								SuspectDosage = (String) entities.get("text");							
								//System.out.println("SuspectDosage #######::"+SuspectDosage);
								mc4.setSuspectDosage(SuspectDosage);
							}						
								
							
						}
					}

					suspectDrugDosageRecords.add(mc4);
					request.setAttribute("suspectDrugDosage", suspectDrugDosageRecords);

				} else if (relType.equalsIgnoreCase("medicalHistory")) {

					MedicalCases mc5 = new MedicalCases();
					String entityType = "";
					String entityText = "";
					String medicalDuration = "";

					JSONArray argumentsArr5 = (JSONArray) arguments.get("arguments");
					for (int j = 0; j < argumentsArr5.size(); j++) {
						JSONObject argumentObj = (JSONObject) argumentsArr5.get(j);
					JSONArray entitiesArr5 = (JSONArray) argumentObj.get("entities");
					for (int k = 0; k < entitiesArr5.size(); k++) {
						
						entities = (JSONObject) entitiesArr5.get(k);
						entityType = (String) entities.get("type");
						if(entityType.equalsIgnoreCase("event")){
							entityText = (String) entities.get("text");
							  mc5.setMedicalHisName(entityText);
							
						} else if(entityType.equalsIgnoreCase("duration")) {
							
							medicalDuration = (String) entities.get("text");
							 mc5.setMedicalHisDuration(medicalDuration);
						} 		
					}
				}
					medicalHistoryRecords.add(mc5);
					request.setAttribute("medicalHistory", medicalHistoryRecords);
				} else if (relType.equalsIgnoreCase("eventDueTo")) {

					MedicalCases mc6 = new MedicalCases();
					StringBuffer sb = new StringBuffer();
					String entityType="";
					String entityText="";
					String medicalDuration="";
					
					JSONArray argumentsArr6 = (JSONArray) arguments.get("arguments");
					for (int j = 0; j < argumentsArr6.size(); j++) {
						JSONObject argumentObj = (JSONObject) argumentsArr6.get(j);
					JSONArray entitiesArr6 = (JSONArray) argumentObj.get("entities");
					for (int k = 0; k < entitiesArr6.size(); k++) {
						
						entities = (JSONObject) entitiesArr6.get(k);
						entityType = (String) entities.get("type");
						if(entityType.equalsIgnoreCase("event")){
							entityText = (String) entities.get("text");
							 sb.append(entityText);
							 sb.append(";");
							
							
						} 	
					}
					}
					mc6.setCausalityEventName(sb.toString());
					request.setAttribute("causalityEvent", mc6.getCausalityEventName());
				}
				
			}
 		}catch (Exception e) {

			e.printStackTrace();
		}
         
         
         
		RequestDispatcher dispatcher = request.getRequestDispatcher("outputML.jsp");
        dispatcher.forward(request, response);
		
		
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		System.out.println("Inside Get...");
		
		ArrayList<MedicalCases> cases = MedicalCasesService.getListOfCases();
        request.setAttribute("cases", cases);

        RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        dispatcher.forward(request, response);

	}

}
