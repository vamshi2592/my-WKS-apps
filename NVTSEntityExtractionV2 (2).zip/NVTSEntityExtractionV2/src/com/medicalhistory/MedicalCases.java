package com.medicalhistory;

public class MedicalCases {
	
	

	    
	    private String caseNumber;
		private String country;
		private int sNo;
		private String createdDate;
		private String narration;
		private String description;
		
		private String entityText_EventBegin;
		private String entityType_EventBegin;
		private String eventDuration;
		private String eventEndDate;
		
		private String entityType_rptOn;
		private String drugName_con;
		private String startDate_con;
		private String endDate_con;
		private String dosage_con;
		
		
		private String suspectName;
		private String suspectStartDt;
		private String suspectEndDt;
		private String suspectDosage;
		private String suspectDuration;
		
		private String medicalHisName;
		private String medicalHisDuration;
		
		private String causalityEventName;	
		

	    public MedicalCases() {
	    }

	    public MedicalCases(int sNo, String country, String caseNumber, String createdDate,String description) {

	        this.country = country;
	        this.caseNumber = caseNumber;
	        this.sNo = sNo;	        
	        this.createdDate = createdDate;
	        this.description = description;
	    }

		public String getCaseNumber() {
			return caseNumber;
		}

		public void setCaseNumber(String caseNumber) {
			this.caseNumber = caseNumber;
		}

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}

		public int getsNo() {
			return sNo;
		}

		public void setsNo(int sNo) {
			this.sNo = sNo+1;
		}

		public String getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getEntityText_EventBegin() {
			return entityText_EventBegin;
		}

		public String setEntityText_EventBegin(String entityText_EventBegin) {
			return this.entityText_EventBegin = entityText_EventBegin;
		}

		public String getEntityType_EventBegin() {
			return entityType_EventBegin;
		}

		public String setEntityType_EventBegin(String entityType_EventBegin) {
			return this.entityType_EventBegin = entityType_EventBegin;
		}

		public String getEntityType_rptOn() {
			return entityType_rptOn;
		}

		public void setEntityType_rptOn(String entityType_rptOn) {
			this.entityType_rptOn = entityType_rptOn;
		}

		public String getDrugName_con() {
			return drugName_con;
		}

		public void setDrugName_con(String drugName_con) {
			this.drugName_con = drugName_con;
		}

		public String getStartDate_con() {
			return startDate_con;
		}

		public void setStartDate_con(String startDate_con) {
			this.startDate_con = startDate_con;
		}

		public String getEndDate_con() {
			return endDate_con;
		}

		public void setEndDate_con(String endDate_con) {
			this.endDate_con = endDate_con;
		}

		public String getDosage_con() {
			return dosage_con;
		}

		public void setDosage_con(String dosage_con) {
			this.dosage_con = dosage_con;
		}

		public String getSuspectName() {
			return suspectName;
		}

		public void setSuspectName(String suspectName) {
			this.suspectName = suspectName;
		}

		public String getSuspectStartDt() {
			return suspectStartDt;
		}

		public void setSuspectStartDt(String suspectStartDt) {
			this.suspectStartDt = suspectStartDt;
		}

		public String getSuspectEndDt() {
			return suspectEndDt;
		}

		public void setSuspectEndDt(String suspectEndDt) {
			this.suspectEndDt = suspectEndDt;
		}

		public String getSuspectDosage() {
			return suspectDosage;
		}

		public void setSuspectDosage(String suspectDosage) {
			this.suspectDosage = suspectDosage;
		}

		public String getEventDuration() {
			return eventDuration;
		}

		public void setEventDuration(String eventDuration) {
			this.eventDuration = eventDuration;
		}

		public String getMedicalHisName() {
			return medicalHisName;
		}

		public void setMedicalHisName(String medicalHisName) {
			this.medicalHisName = medicalHisName;
		}

		public String getMedicalHisDuration() {
			return medicalHisDuration;
		}

		public void setMedicalHisDuration(String medicalHisDuration) {
			this.medicalHisDuration = medicalHisDuration;
		}

		public String getEventEndDate() {
			return eventEndDate;
		}

		public void setEventEndDate(String eventEndDate) {
			this.eventEndDate = eventEndDate;
		}

		public String getSuspectDuration() {
			return suspectDuration;
		}

		public void setSuspectDuration(String suspectDuration) {
			this.suspectDuration = suspectDuration;
		}

		public String getCausalityEventName() {
			return causalityEventName;
		}

		public void setCausalityEventName(String causalityEventName) {
			this.causalityEventName = causalityEventName;
		}
		

}
